import os
import argparse
import json
import numpy as np
from tqdm import tqdm
import cv2

import torch
from torch.utils.data import DataLoader

from badminton_lab_evaluate import predict_location, get_ensemble_weight, generate_inpaint_mask
from badminton_lab_dataset import Shuttlecock_Trajectory_Dataset, Video_IterableDataset
from badminton_lab_utils.tracking_io import *


def _to_numpy_indices(indices):
    """Safely convert indices tensor/array to numpy."""
    if torch.is_tensor(indices):
        return indices.detach().cpu().numpy()
    # some datasets may return numpy already
    return np.asarray(indices)


def predict(indices, y_pred=None, c_pred=None, img_scaler=(1, 1)):
    """Predict coordinates from heatmap or inpainted coordinates.

    Args:
        indices: indices of input sequence with shape (N, L, 2)
        y_pred: predicted heatmap sequence with shape (N, L, H, W)
        c_pred: predicted inpainted coordinates sequence with shape (N, L, 2)
        img_scaler: (w_scaler, h_scaler) mapping TrackNet input size -> decoded video size

    Returns:
        pred_dict: {'Frame':[], 'X':[], 'Y':[], 'Visibility':[]}
    """

    pred_dict = {'Frame': [], 'X': [], 'Y': [], 'Visibility': []}

    batch_size, seq_len = indices.shape[0], indices.shape[1]
    indices = _to_numpy_indices(indices)

    # Transform input for heatmap prediction
    if y_pred is not None:
        y_pred = (y_pred > 0.5)
        if torch.is_tensor(y_pred):
            y_pred = y_pred.detach().cpu().numpy()
        y_pred = to_img_format(y_pred)  # (N, L, H, W)

    # Transform input for coordinate prediction
    if c_pred is not None and torch.is_tensor(c_pred):
        c_pred = c_pred.detach().cpu().numpy()

    prev_f_i = -1
    for n in range(batch_size):
        for f in range(seq_len):
            f_i = int(indices[n][f][1])
            if f_i != prev_f_i:
                if c_pred is not None:
                    # Predict from coordinate
                    c_p = c_pred[n][f]
                    cx_pred = int(c_p[0] * WIDTH * img_scaler[0])
                    cy_pred = int(c_p[1] * HEIGHT * img_scaler[1])
                elif y_pred is not None:
                    # Predict from heatmap
                    y_p = y_pred[n][f]
                    bbox_pred = predict_location(to_img(y_p))
                    cx_pred = int(bbox_pred[0] + bbox_pred[2] / 2)
                    cy_pred = int(bbox_pred[1] + bbox_pred[3] / 2)
                    cx_pred = int(cx_pred * img_scaler[0])
                    cy_pred = int(cy_pred * img_scaler[1])
                else:
                    raise ValueError('Invalid input: must provide y_pred or c_pred')

                vis_pred = 0 if (cx_pred == 0 and cy_pred == 0) else 1
                pred_dict['Frame'].append(f_i)
                pred_dict['X'].append(cx_pred)
                pred_dict['Y'].append(cy_pred)
                pred_dict['Visibility'].append(vis_pred)
                prev_f_i = f_i
            else:
                break

    return pred_dict


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--video_file', type=str, required=True, help='file path of the video')
    parser.add_argument('--tracknet_file', type=str, required=True, help='file path of the TrackNet checkpoint')
    parser.add_argument('--inpaintnet_file', type=str, default='', help='file path of the InpaintNet checkpoint (optional)')
    parser.add_argument('--batch_size', type=int, default=16, help='batch size for inference')
    parser.add_argument('--eval_mode', type=str, default='weight', choices=['nonoverlap', 'average', 'weight'], help='evaluation mode')
    parser.add_argument('--max_sample_num', type=int, default=1800, help='maximum number of frames to sample for generating median image')
    parser.add_argument('--video_range', type=lambda splits: [int(s) for s in splits.split(',')], default=None, help='start_second,end_second for median image')
    parser.add_argument('--save_dir', type=str, default='pred_result', help='directory to save outputs')
    parser.add_argument('--large_video', action='store_true', default=False, help='process large video with iterable dataset')
    parser.add_argument('--output_video', action='store_true', default=False, help='output mp4 with predicted trajectory')
    parser.add_argument('--traj_len', type=int, default=8, help='trajectory tail length')
    parser.add_argument('--device', type=str, default='auto', choices=['auto', 'cuda', 'cpu'], help='inference device')
    args = parser.parse_args()

    # === Windows Fix: DataLoader workers ===
    num_workers = 0

    # Device
    if args.device == 'auto':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    else:
        device = torch.device(args.device)

    video_file = args.video_file
    video_name = os.path.splitext(os.path.basename(video_file))[0]
    video_range = args.video_range if args.video_range else None
    large_video = args.large_video

    os.makedirs(args.save_dir, exist_ok=True)

    out_csv_file = os.path.join(args.save_dir, f'{video_name}_ball.csv')
    out_video_file = os.path.join(args.save_dir, f'{video_name}.mp4')
    out_meta_file = os.path.join(args.save_dir, f'{video_name}_meta.json')

    # Load model (map_location so it works on CPU too)
    tracknet_ckpt = torch.load(args.tracknet_file, map_location=device)
    tracknet_seq_len = tracknet_ckpt['param_dict']['seq_len']
    bg_mode = tracknet_ckpt['param_dict']['bg_mode']
    tracknet = get_model('TrackNet', tracknet_seq_len, bg_mode).to(device)
    tracknet.load_state_dict(tracknet_ckpt['model'])

    if args.inpaintnet_file:
        inpaintnet_ckpt = torch.load(args.inpaintnet_file, map_location=device)
        inpaintnet_seq_len = inpaintnet_ckpt['param_dict']['seq_len']
        inpaintnet = get_model('InpaintNet').to(device)
        inpaintnet.load_state_dict(inpaintnet_ckpt['model'])
    else:
        inpaintnet = None

    # Read decoded video size (OpenCV)
    cap = cv2.VideoCapture(video_file)
    if not cap.isOpened():
        raise FileNotFoundError(f'Cannot open video: {video_file}')
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    cap.release()

    # Scale TrackNet input space -> decoded video space
    w_scaler, h_scaler = w / WIDTH, h / HEIGHT
    img_scaler = (w_scaler, h_scaler)

    tracknet_pred_dict = {
        'Frame': [], 'X': [], 'Y': [], 'Visibility': [], 'Inpaint_Mask': [],
        'Img_scaler': (w_scaler, h_scaler), 'Img_shape': (w, h)
    }

    # =========================
    # TrackNet inference
    # =========================
    tracknet.eval()
    seq_len = tracknet_seq_len

    if args.eval_mode == 'nonoverlap':
        # Create dataset with non-overlap sampling
        if large_video:
            dataset = Video_IterableDataset(
                video_file, seq_len=seq_len, sliding_step=seq_len, bg_mode=bg_mode,
                max_sample_num=args.max_sample_num, video_range=video_range
            )
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)
            print(f'Video length: {dataset.video_len}')
        else:
            frame_list = generate_frames(video_file)
            dataset = Shuttlecock_Trajectory_Dataset(
                seq_len=seq_len, sliding_step=seq_len, data_mode='heatmap', bg_mode=bg_mode,
                frame_arr=np.array(frame_list)[:, :, :, ::-1], padding=True
            )
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=num_workers, drop_last=False)

        for _, (i, x) in enumerate(tqdm(data_loader)):
            x = x.float().to(device)
            with torch.no_grad():
                y_pred = tracknet(x).detach().cpu()
            tmp_pred = predict(i, y_pred=y_pred, img_scaler=img_scaler)
            for key in tmp_pred.keys():
                tracknet_pred_dict[key].extend(tmp_pred[key])

    else:
        # Create dataset with overlap sampling for temporal ensemble
        if large_video:
            dataset = Video_IterableDataset(
                video_file, seq_len=seq_len, sliding_step=1, bg_mode=bg_mode,
                max_sample_num=args.max_sample_num, video_range=video_range
            )
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)
            video_len = dataset.video_len
            print(f'Video length: {video_len}')
        else:
            frame_list = generate_frames(video_file)
            dataset = Shuttlecock_Trajectory_Dataset(
                seq_len=seq_len, sliding_step=1, data_mode='heatmap', bg_mode=bg_mode,
                frame_arr=np.array(frame_list)[:, :, :, ::-1]
            )
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=num_workers, drop_last=False)
            video_len = len(frame_list)

        num_sample, sample_count = video_len - seq_len + 1, 0
        buffer_size = seq_len - 1
        batch_i = torch.arange(seq_len)
        frame_i = torch.arange(seq_len - 1, -1, -1)
        y_pred_buffer = torch.zeros((buffer_size, seq_len, HEIGHT, WIDTH), dtype=torch.float32)
        weight = get_ensemble_weight(seq_len, args.eval_mode)

        for _, (i, x) in enumerate(tqdm(data_loader)):
            x = x.float().to(device)
            b_size = i.shape[0]
            with torch.no_grad():
                y_pred = tracknet(x).detach().cpu()

            y_pred_buffer = torch.cat((y_pred_buffer, y_pred), dim=0)
            ensemble_i = torch.empty((0, 1, 2), dtype=torch.float32)
            ensemble_y_pred = torch.empty((0, 1, HEIGHT, WIDTH), dtype=torch.float32)

            for b in range(b_size):
                if sample_count < buffer_size:
                    y_e = y_pred_buffer[batch_i + b, frame_i].sum(0) / (sample_count + 1)
                else:
                    y_e = (y_pred_buffer[batch_i + b, frame_i] * weight[:, None, None]).sum(0)

                ensemble_i = torch.cat((ensemble_i, i[b][0].reshape(1, 1, 2)), dim=0)
                ensemble_y_pred = torch.cat((ensemble_y_pred, y_e.reshape(1, 1, HEIGHT, WIDTH)), dim=0)
                sample_count += 1

                if sample_count == num_sample:
                    # pad last batch
                    y_zero_pad = torch.zeros((buffer_size, seq_len, HEIGHT, WIDTH), dtype=torch.float32)
                    y_pred_buffer = torch.cat((y_pred_buffer, y_zero_pad), dim=0)

                    for f in range(1, seq_len):
                        y_last = y_pred_buffer[batch_i + b + f, frame_i].sum(0) / (seq_len - f)
                        ensemble_i = torch.cat((ensemble_i, i[-1][f].reshape(1, 1, 2)), dim=0)
                        ensemble_y_pred = torch.cat((ensemble_y_pred, y_last.reshape(1, 1, HEIGHT, WIDTH)), dim=0)

            tmp_pred = predict(ensemble_i, y_pred=ensemble_y_pred, img_scaler=img_scaler)
            for key in tmp_pred.keys():
                tracknet_pred_dict[key].extend(tmp_pred[key])

            y_pred_buffer = y_pred_buffer[-buffer_size:]

    # =========================
    # InpaintNet (optional)
    # =========================
    if inpaintnet is not None:
        inpaintnet.eval()
        seq_len = inpaintnet_seq_len
        tracknet_pred_dict['Inpaint_Mask'] = generate_inpaint_mask(tracknet_pred_dict, th_h=h * 0.05)
        inpaint_pred_dict = {'Frame': [], 'X': [], 'Y': [], 'Visibility': []}

        if args.eval_mode == 'nonoverlap':
            dataset = Shuttlecock_Trajectory_Dataset(
                seq_len=seq_len, sliding_step=seq_len, data_mode='coordinate', pred_dict=tracknet_pred_dict, padding=True
            )
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=num_workers, drop_last=False)

            for _, (i, coor_pred, inpaint_mask) in enumerate(tqdm(data_loader)):
                coor_pred, inpaint_mask = coor_pred.float(), inpaint_mask.float()
                with torch.no_grad():
                    coor_inpaint = inpaintnet(coor_pred.to(device), inpaint_mask.to(device)).detach().cpu()
                    coor_inpaint = coor_inpaint * inpaint_mask + coor_pred * (1 - inpaint_mask)

                th_mask = ((coor_inpaint[:, :, 0] < COOR_TH) & (coor_inpaint[:, :, 1] < COOR_TH))
                coor_inpaint[th_mask] = 0.

                tmp_pred = predict(i, c_pred=coor_inpaint, img_scaler=img_scaler)
                for key in tmp_pred.keys():
                    inpaint_pred_dict[key].extend(tmp_pred[key])

        else:
            dataset = Shuttlecock_Trajectory_Dataset(seq_len=seq_len, sliding_step=1, data_mode='coordinate', pred_dict=tracknet_pred_dict)
            data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=num_workers, drop_last=False)
            weight = get_ensemble_weight(seq_len, args.eval_mode)

            num_sample, sample_count = len(dataset), 0
            buffer_size = seq_len - 1
            batch_i = torch.arange(seq_len)
            frame_i = torch.arange(seq_len - 1, -1, -1)
            coor_inpaint_buffer = torch.zeros((buffer_size, seq_len, 2), dtype=torch.float32)

            for _, (i, coor_pred, inpaint_mask) in enumerate(tqdm(data_loader)):
                coor_pred, inpaint_mask = coor_pred.float(), inpaint_mask.float()
                b_size = i.shape[0]

                with torch.no_grad():
                    coor_inpaint = inpaintnet(coor_pred.to(device), inpaint_mask.to(device)).detach().cpu()
                    coor_inpaint = coor_inpaint * inpaint_mask + coor_pred * (1 - inpaint_mask)

                th_mask = ((coor_inpaint[:, :, 0] < COOR_TH) & (coor_inpaint[:, :, 1] < COOR_TH))
                coor_inpaint[th_mask] = 0.

                coor_inpaint_buffer = torch.cat((coor_inpaint_buffer, coor_inpaint), dim=0)
                ensemble_i = torch.empty((0, 1, 2), dtype=torch.float32)
                ensemble_coor_inpaint = torch.empty((0, 1, 2), dtype=torch.float32)

                for b in range(b_size):
                    if sample_count < buffer_size:
                        c_e = coor_inpaint_buffer[batch_i + b, frame_i].sum(0) / (sample_count + 1)
                    else:
                        c_e = (coor_inpaint_buffer[batch_i + b, frame_i] * weight[:, None]).sum(0)

                    ensemble_i = torch.cat((ensemble_i, i[b][0].view(1, 1, 2)), dim=0)
                    ensemble_coor_inpaint = torch.cat((ensemble_coor_inpaint, c_e.view(1, 1, 2)), dim=0)
                    sample_count += 1

                    if sample_count == num_sample:
                        coor_zero_pad = torch.zeros((buffer_size, seq_len, 2), dtype=torch.float32)
                        coor_inpaint_buffer = torch.cat((coor_inpaint_buffer, coor_zero_pad), dim=0)

                        for f in range(1, seq_len):
                            c_last = coor_inpaint_buffer[batch_i + b + f, frame_i].sum(0) / (seq_len - f)
                            ensemble_i = torch.cat((ensemble_i, i[-1][f].view(1, 1, 2)), dim=0)
                            ensemble_coor_inpaint = torch.cat((ensemble_coor_inpaint, c_last.view(1, 1, 2)), dim=0)

                th_mask2 = ((ensemble_coor_inpaint[:, :, 0] < COOR_TH) & (ensemble_coor_inpaint[:, :, 1] < COOR_TH))
                ensemble_coor_inpaint[th_mask2] = 0.

                tmp_pred = predict(ensemble_i, c_pred=ensemble_coor_inpaint, img_scaler=img_scaler)
                for key in tmp_pred.keys():
                    inpaint_pred_dict[key].extend(tmp_pred[key])

                coor_inpaint_buffer = coor_inpaint_buffer[-buffer_size:]

    # =========================
    # Write outputs
    # =========================
    pred_dict = inpaint_pred_dict if inpaintnet is not None else tracknet_pred_dict
    write_pred_csv(pred_dict, save_file=out_csv_file)

    # Meta file for downstream (iOS overlay / calibration transform)
    try:
        # best-effort max among visible points
        xs = [x for x, v in zip(pred_dict.get('X', []), pred_dict.get('Visibility', [])) if v == 1]
        ys = [y for y, v in zip(pred_dict.get('Y', []), pred_dict.get('Visibility', [])) if v == 1]
        max_x = max(xs) if xs else 0
        max_y = max(ys) if ys else 0
    except Exception:
        max_x, max_y = None, None

    meta = {
        "video_file": os.path.abspath(video_file),
        "video_name": video_name,
        "video_width": w,
        "video_height": h,
        "fps": fps,
        "device": str(device),
        "tracknet_input_width": WIDTH,
        "tracknet_input_height": HEIGHT,
        "img_scaler": [w_scaler, h_scaler],
        "csv_coord_space": "video_pixels",
        "csv_columns": ["Frame", "Visibility", "X", "Y"],
        "csv_path": os.path.abspath(out_csv_file),
        "max_visible_x": max_x,
        "max_visible_y": max_y,
        "note": (
            "CSV X,Y are scaled to match OpenCV-decoded frames (video_width x video_height). "
            "If iOS playback shows a rotated video, apply AVAssetTrack.preferredTransform when mapping points to screen."
        )
    }

    with open(out_meta_file, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    if args.output_video:
        write_pred_video(video_file, pred_dict, save_file=out_video_file, traj_len=args.traj_len)

    print('Done.')
